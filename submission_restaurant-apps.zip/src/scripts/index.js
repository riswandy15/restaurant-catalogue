import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import data from '../scripts/data/data.json';

const menu = document.querySelector('#menu');
const hero = document.querySelector('.hero');
const main = document.querySelector('main');
const drawer = document.querySelector('#drawer');

        const listRestaurantElement = document.querySelector("#listRestaurant");
        listRestaurantElement.innerHTML = "";

        data.restaurants.forEach(restaurant => {
            listRestaurantElement.innerHTML += `

            <article class="post-item">
                <img class="post-item__thumbnail"
                    src="${restaurant.pictureId}" alt="Gambar Restaurant_${restaurant.name}">
                <div class="post-item__content">
                    <h1 class="post-item__title">${restaurant.name} - ${restaurant.city}</h1>
                    <h2>Rating: ${restaurant.rating}</h2>
                    <p class="post-item__description">${restaurant.description}</p>
                </div>
            </article>    
                       
            `;
        });



menu.addEventListener('click', function (event){
    drawer.classList.toggle('open');
    event.stopPropagation;
});

hero.addEventListener('click', function (event){
    drawer.classList.remove('open');
});

main.addEventListener('click', function (event){
    drawer.classList.remove('open');
});